/// <reference types="@figma/plugin-typings" />

/**
 * Nomes de componentes/instâncias sempre ignorados pela descoberta
 * automática: não viram card, não contam para Core Web/Core App, e
 * sua subárvore inteira também não é percorrida (pode haver
 * componentes reais aninhados neles, mas essas camadas são
 * consideradas "chrome" fixo da tela, não conteúdo a especificar).
 *
 * Para adicionar/remover um nome desta lista, edite só este array —
 * nenhuma outra parte do código precisa mudar.
 */
const IGNORED_COMPONENT_NAMES = [
  "Header Web",
  "[IB-Leg] Acessibility Settings Bar",
  "[IB-Leg] Header",
  "[IB-Leg] Navigation Bar",
  "[IB-Leg] Footer"
];

/**
 * Decide se um componente/instância é "reconhecido" (tem uma regra
 * cadastrada em accessibility-rules.ts) — fornecida por quem chama
 * (analyzer.ts), para discovery.ts continuar sem depender do motor de
 * regras diretamente. Assíncrona porque resolver o nome do componente
 * principal de uma INSTANCE exige `getMainComponentAsync`.
 */
export type ComponentRecognizer = (node: InstanceNode | ComponentNode) => Promise<boolean>;

/**
 * Percorre a árvore a partir do node da tela selecionada e decide,
 * componente por componente, se aprofunda ou não:
 *
 * - Componente RECONHECIDO (tem regra na planilha, via `isRecognized`)
 *   → vira card, e a busca NÃO desce para dentro dele.
 * - Componente NÃO reconhecido → NÃO vira card sozinho, mas a busca
 *   continua descendo dentro dele — pode haver componentes reais lá
 *   dentro (ex.: um "Header Flow" que é só uma composição do arquivo,
 *   sem regra própria, mas contém um "Breadcrumb" e um "Header
 *   Product" que são reconhecidos e geram card cada um).
 *
 * Esse critério (reconhecido = não aprofunda; desconhecido =
 * aprofunda) substitui as duas versões anteriores — "sempre para no
 * primeiro" e "sempre desce em tudo" — que geravam ou componentes
 * demais (poluição visual) ou componentes de menos (composições como
 * "Header Flow" sendo ignoradas por inteiro), dependendo do arquivo.
 *
 * "Header Web" e os demais nomes de `IGNORED_COMPONENT_NAMES`
 * continuam ignorados por completo: não viram card, não contam para
 * Core Web/Core App, e sua subárvore também não é percorrida.
 *
 * Componentes/camadas OCULTOS no Figma (`node.visible === false`)
 * também são ignorados por completo, junto com toda a sua subárvore
 * — a visibilidade de um ancestral nunca é copiada para os filhos no
 * Figma, então o corte precisa acontecer na hora de decidir se desce.
 */
export async function discoverTopLevelComponents(
  root: SceneNode,
  isRecognized: ComponentRecognizer
): Promise<(InstanceNode | ComponentNode)[]> {
  const found: (InstanceNode | ComponentNode)[] = [];

  async function walk(node: SceneNode): Promise<void> {
    if ("visible" in node && !node.visible) {
      return; // oculto: ignora completamente, inclusive a subárvore
    }

    if (IGNORED_COMPONENT_NAMES.includes(node.name)) {
      return; // ignora completamente, inclusive a subárvore
    }

    if (node.type === "INSTANCE" || node.type === "COMPONENT") {
      if (await isRecognized(node)) {
        found.push(node);
        return; // reconhecido: vira card, não desce mais
      }
      // não reconhecido: não vira card sozinho, mas continua a busca
      // dentro dele (pode haver componentes reais lá dentro).
    }

    if ("children" in node) {
      for (const child of node.children) {
        await walk(child);
      }
    }
  }

  if ("children" in root) {
    for (const child of root.children) {
      await walk(child);
    }
  }

  return found;
}
