/**
 * ATENÇÃO — ESTE ARQUIVO É UM ESPELHO DIRETO DA PLANILHA.
 *
 * Fonte: "Acessibilidade_Colmeia_Web.xlsx" (aba "Acessibilidade Core
 * Web"), fornecida pelo time de acessibilidade em 10/09/2026 —
 * substitui a planilha anterior ("Extracao_Acessibilidade_Core_Web_
 * 70_Componentes.xlsx") como base de verdade.
 *
 * COMO ATUALIZAR QUANDO A PLANILHA MUDAR
 * ---------------------------------------
 * 1. Abra a planilha nova e confira se as colunas continuam sendo,
 *    nesta ordem: Categoria | Componente | Estados | Verbalização
 *    esperada | Tipo | Foco.
 * 2. Para cada linha (uma por componente), adicione/edite um objeto
 *    neste array seguindo a interface `AccessibilityRuleRecord`
 *    abaixo. Copie o texto das células literalmente — inclusive
 *    quebras de linha (uma string JS com `\n` para cada linha da
 *    célula) e as aspas curvas (“ ”) que a planilha usa.
 * 3. A coluna "Tipo" precisa ser um destes 8 valores exatos: "Botão",
 *    "Entrada", "Link", "Título", "Imagem", "Decorativo", "Estrutura",
 *    "Não interativo" — são os únicos que accessibility-rules.ts sabe
 *    mapear para as categorias do plugin (ver
 *    TIPO_PLANILHA_PARA_MARKUP_TYPE nesse arquivo). Um valor fora
 *    dessa lista faz o componente cair em "Não especificado".
 * 4. A coluna "Foco" precisa ser "Sim", "Não" ou "Apenas elementos
 *    interativos" (ver Regra 3 e 4 do documento de regras — Estrutura
 *    sempre usa "Apenas elementos interativos": a estrutura em si não
 *    recebe número de Ordem de foco, só os componentes internos dela).
 * 5. NÃO edite `accessibility-rules.ts` para registrar um componente
 *    novo — aquele arquivo só TRANSFORMA os registros daqui em regras
 *    do motor (`ComponentTypeRule`). Basta adicionar o registro aqui
 *    que a regra correspondente é gerada automaticamente.
 * 6. Campos vazios na planilha viram `null` aqui — não invente
 *    conteúdo para preenchê-los.
 * 7. Se o nome do componente principal no Figma divergir do nome
 *    aqui (já aconteceu: "Botao defaut" em vez de "Botão Default"),
 *    NÃO crie um registro novo — adicione o nome real em
 *    `aliasesDeNome` no registro existente.
 * 8. Depois de editar, rode `npm run typecheck` e `npm run build`
 *    para confirmar que nada quebrou.
 */

export interface AccessibilityRuleRecord {
  /** Categoria do Design System (ex.: "Action", "Inputs", "Content"). Informativo; não usado pelo motor ainda. */
  categoria: string;
  /** Nome do componente exatamente como está na planilha e (esperado) no componente principal do Figma. */
  componente: string;
  /** Lista de estados possíveis do componente, em texto livre (como veio da planilha). Informativo por ora — ver ComponentTypeRule.states. */
  estados: string | null;
  /**
   * Texto de verbalização esperada, literalmente como veio da célula
   * (pode ter múltiplas linhas/estados, ou ser um texto corrido
   * explicativo com exemplo embutido — os dois casos são usados
   * INTEIROS como verbalização inicial, editável pelo designer;
   * nenhum dos dois fica vazio só porque não é uma lista limpa de
   * "Estado: texto"). Placeholders usam "(Nome)", "[Nome]" ou
   * "{Nome}" dependendo da linha — ver src/rules/placeholders.ts.
   */
  verbalizacaoEsperada: string | null;
  /**
   * Valor literal da coluna "Tipo" da planilha — um dos 8 tipos
   * válidos do documento de regras (Botão, Entrada, Link, Título,
   * Imagem, Decorativo, Estrutura, Não interativo). Mapeado 1:1 para
   * as categorias do plugin em accessibility-rules.ts.
   */
  tipo: string | null;
  /**
   * Coluna "Foco" da planilha: "Sim" | "Não" | "Apenas elementos
   * interativos" | null. Determina a Ordem de foco (Regra 3/4) — só
   * "Sim" torna o componente elegível a receber um número de foco.
   */
  foco: string | null;
  /**
   * NÃO vem da planilha — campo de extensão para quem for dar
   * manutenção depois. Se o nome do componente principal no arquivo
   * Figma real divergir do valor de `componente`, liste aqui os
   * nomes alternativos aceitos. Deixe `undefined` quando não houver
   * divergência conhecida.
   */
  aliasesDeNome?: string[];
}

export const accessibilityRuleRecords: AccessibilityRuleRecord[] = [
  {
    "categoria": "Action",
    "componente": "Button Group",
    "estados": "Habilitado, Foco, Desabilitado e Loading. O grupo em si não possui estados próprios.",
    "verbalizacaoEsperada": "Habilitado: “[verbo do botão], botão.”\nFoco: “[verbo do botão], botão.”\nDesabilitado: “[verbo do botão], botão, indisponível.”\nLoading: “[verbo do botão], carregando, botão indisponível.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Action",
    "componente": "Button Icon",
    "estados": "Habilitado, Disabled, Focus, Hover.",
    "verbalizacaoEsperada": "Habilitado: “Notificações, botão.”\nDisabled: “Notificações, botão, indisponível.”\nFocus: “Notificações, botão.”\nCom badge: “Notificações, novas.”",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Button Mini",
    "estados": "Habilitado, Disabled, Focus, Hover.",
    "verbalizacaoEsperada": "Habilitado: “Editar, botão.”\nDisabled: “Editar, botão, indisponível.”\nFocus: “Editar, botão.”",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Button Primary",
    "estados": "Habilitado, Hover, Focus, Loading, Disabled.",
    "verbalizacaoEsperada": "Habilitado/Focus: “[Verbo do botão], botão”.\nLoading macOS: “[Verbo do botão], carregando, botão, escurecido”.\nLoading Windows: “Indisponível, botão, [Verbo do botão]”.\nDisabled macOS: “[Verbo do botão], botão, escurecido”.\nDisabled Windows: “Indisponível, botão, [Verbo do botão]”.",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Button Secondary",
    "estados": "Habilitado, Hover, Focus, Loading, Disabled.",
    "verbalizacaoEsperada": "Habilitado/Focus: “[Verbo do botão], botão”.\nLoading macOS: “[Verbo do botão], carregando, botão, escurecido”.\nLoading Windows: “Indisponível, botão, [Verbo do botão]”.\nDisabled macOS: “[Verbo do botão], botão, escurecido”.\nDisabled Windows: “Indisponível, botão, [Verbo do botão]”.",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Shortcut",
    "estados": "Habilitado, Focus, Hover, Disabled.",
    "verbalizacaoEsperada": "Habilitado/Focus: “{rótulo}, link.”\nDisabled: “{rótulo}, link, indisponível.”",
    "tipo": "Link",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Menu Button",
    "estados": "Recolhido, Expandido, Focus e Hover.",
    "verbalizacaoEsperada": "Recolhido: “Ações do registro, botão, menu recolhido.”\nExpandido: “Ações do registro, botão, menu expandido.”\nItem focado: “Editar, item de menu.”",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Link Icon",
    "estados": "Habilitado, Focus, Hover.",
    "verbalizacaoEsperada": "Habilitado/Focus: “Central de ajuda, link.”\nExterno: Quando for um link externo com ou sem ícone, o destino deve ser verbalizado junto ao tipo de elemento. Por exemplo: “Política de privacidade, link externo.”",
    "tipo": "Link",
    "foco": "Sim"
  },
  {
    "categoria": "Content",
    "componente": "Icon Shape",
    "estados": "Padrão; estático, sem foco, hover ou desabilitado.",
    "verbalizacaoEsperada": "Não precisa ser lido por leitores de tela.",
    "tipo": "Decorativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Currency",
    "estados": "Padrão, Mascarado; variação positiva ou negativa apenas visual.",
    "verbalizacaoEsperada": "Valor visível: “Texto do valor”\nValor mascarado: “Valor oculto por privacidade.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Paragraph",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "Leitura linear do conteúdo. Exemplo: “O Sicredi oferece soluções para o seu negócio crescer de forma cooperativa.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Icon",
    "estados": "Herda estados do componente pai.",
    "verbalizacaoEsperada": "Decorativo: o leitor de tela ignora o ícone.\n Exemplo: nenhum anúncio.\n\nSemântico: o leitor de tela lê o rótulo associado.\n Exemplo: “Notificações.”\n\nDentro de botão ou link: a leitura é feita a partir do elemento pai.\n Exemplo: “Editar, botão.”",
    "tipo": "Decorativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Topic",
    "estados": "Estático, sem foco, hover ou desabilitado.",
    "verbalizacaoEsperada": "Leitor lê apenas o Label. Exemplo: “Clique em Baixar para realizar o download da ferramenta Diagnóstico Sicredi.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Brand",
    "estados": "Estático; quando usado como link, possui interação.",
    "verbalizacaoEsperada": "“Logotipo Sicredi”.",
    "tipo": "Imagem",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Description",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "Leitura normal; quando associado, é lido com rótulo principal. Exemplo: “Etapa 1 de 4”.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Empty State",
    "estados": "Estático; botão interno segue Button Primary.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar a mensagem principal, seguida da descrição e do botão, quando presente.\n\nExemplo: “Sem notificações novas. Você ainda não recebeu avisos. Adicionar nova notificação, botão.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Content",
    "componente": "Accordion",
    "estados": "Expandido e Recolhido.",
    "verbalizacaoEsperada": "Foco/recolhido: “[título], botão recolhido.”\nExpandido: “[título], botão expandido.” Após a expansão, o conteúdo interno é anunciado em sequência, permitindo uma leitura contínua pelo leitor de tela.",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Content",
    "componente": "Image",
    "estados": "Estático.",
    "verbalizacaoEsperada": "Quando a imagem possui propósito informativo, o leitor de tela anuncia o texto alternativo definido no alt.\n Exemplo: “Gráfico de barras mostrando o aumento de clientes no último trimestre.”\n\nQuando a imagem é meramente decorativa, o alt pode estar vazio para que o leitor de tela a ignore.",
    "tipo": "Imagem",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Heading",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o conteúdo do Label e o nível hierárquico correspondente.\n\nExemplo: “Meus cartões, título de nível 2.”",
    "tipo": "Título",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "List Content",
    "estados": "Sem estados próprios.",
    "verbalizacaoEsperada": "A leitura verbaliza apenas as informações que existirem e reflete a ordem lógica do conteúdo, sempre começando pelo lado esquerdo. Ou seja, um item com todas as propriedades ativas será lido na sequência:\n\n“{Support element}. {Description 01}. {Label 01}. {Description 02}. {Label 02}. {Tag}. {Button Mini}.”\n\nExemplos:\n\nItem com ícone: “Ícone carro. Seguro Auto. Fiat. Placa. ABC-1234”\nNotificação: “Novo. Crédito. Nova linha de crédito disponível para sua empresa. Conferir. Ontem às 12:30.”\nTransação: “R$ 500,00. Recebimentos. Banco Itaú. Detalhes.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Content",
    "componente": "List Ghost",
    "estados": "Padrão, estático.",
    "verbalizacaoEsperada": "O leitor de tela lê os pares de informação de forma contínua, facilitando a compreensão do conteúdo.\n\nExemplo: “Ícone Agência. Agência 1234. Conta 56789-0.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Credit Card",
    "estados": "Estático.",
    "verbalizacaoEsperada": "Quando o cartão for exibido junto a informações complementares, o leitor de tela deve anunciar o conteúdo de forma contextual.\n Exemplo: “Cartão Sicredi Visa Gold, final 1234.”\n\nQuando for uma versão genérica, sem bandeira, a leitura deve se apoiar nas informações textuais próximas.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Pagination",
    "estados": "Estados herdados de Dropdown e Button Icon.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar o rótulo acessível seguindo a ordem de renderização em tela:\n\n“Dropdown, description, botão de voltar, páginas, botão de avançar.”\n\nExemplo: “10 itens por página, 10 selecionado. 1-10 de 30 itens. Página 1 de 3. Página anterior desativada. Próxima página, botão.”",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Content",
    "componente": "Table",
    "estados": "Default, Linhas selecionadas, Sem dados.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar o rótulo acessível seguindo a ordem das colunas e linhas em tela:\n“Tipo do componente, total de linhas e colunas, linha a linha.”\nSe estiver habilitada a seleção de linhas, o seletor é anunciado por linha, antes dos dados.\nSe estiverem habilitados botões, os botões são anunciados por linha, ao final dos dados. \nExemplo:\n“Tabela de lançamentos.\n 4 linhas exibidas de um total de 30.\n 5 colunas: Seleção, Lançamento, Nome, Número do CPF, Valor total, Status.\n Linha 1.\n Não selecionada.\n Nome: Rosana de Lima.\n Valor total: 150 reais.\n Status: Autorizado.\n Linha 2.\n Selecionada.\n Nome: Pedro Luiz Sousa.\n Valor total: 440 reais.\n Status: Pendente.\n Barra de ação.\n 2 itens selecionados.\n Ações disponíveis: Excluir, botão. Autorizar, botão.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Card",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "O leitor de tela percorre e lê apenas os elementos internos, conforme sua própria hierarquia semântica. O Card não é anunciado como elemento independente.",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Banner Image Full",
    "estados": "Habilitado, Focus, Hover, relacionados à ação.",
    "verbalizacaoEsperada": "A leitura segue a ordem do conteúdo informativo antes da ação, ou seja, o leitor anuncia o título e, quando existir, a descrição. Por fim, anuncia o rótulo do botão.\n\nExemplo: “Seu crédito foi aprovado! Veja as condições especiais selecionadas para você. Saiba mais, botão.”",
    "tipo": "Imagem",
    "foco": "Não"
  },
  {
    "categoria": "Containers",
    "componente": "Modal",
    "estados": "Aberto e Fechado; tipos Default, Danger e Positive.",
    "verbalizacaoEsperada": "Quando o modal é aberto, o leitor de tela anuncia o título e, em seguida, lê todo o conteúdo em sequência, incluindo mensagens, campos e botões.\n\nExemplo: “Excluir registro, diálogo. Deseja realmente excluir este item? Cancelar, botão. Confirmar, botão.”\n\nAo fechar, o leitor de tela anuncia: “Diálogo fechado.”\n\nComportamento por tipo de modal:\n\nDefault: comunica ações neutras ou informativas, sem urgência.\n Exemplo de verbalização: “Detalhes da conta, diálogo.”\n\nDanger: indica ações críticas ou destrutivas.\n Exemplo: “Excluir registro, diálogo de atenção.”\n\nPositive: reforça ações concluídas com sucesso.\n Exemplo: “Transferência realizada, diálogo de confirmação.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Cookies",
    "estados": "Visível e Aceito.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o banner, iniciando a leitura pelo Heading, seguido da descrição. Por fim, o botão é verbalizado como ação de consentimento, por exemplo: “Permitir todos, botão”.\n\nExemplo: “Cookies. Utilizamos cookies neste site para melhorar sua experiência de navegação, de acordo com nossa Política de Cookies, link externo. Permitir todos, botão.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Fixed Bar",
    "estados": "Estrutural, sem estados próprios.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar as ações disponíveis na barra conforme a ordem visual e hierárquica.\n\nExemplo: “Confirmar, botão. Cancelar, botão.”\n\nQuando houver conteúdo adicional no slot, ele deve ser lido antes das ações.\n\nExemplo: “Total: R$ 1.000,00. Fazer pagamento, botão.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Drawer",
    "estados": "Aberto e Fechado.",
    "verbalizacaoEsperada": "A verbalização descreve a Drawer como uma janela lateral temporária, informando seu título. Ao pressionar Tab, a leitura segue respeitando a ordem estrutural do componente.\n\nAberto: “{heading}. Janela lateral aberta.”\n Exemplo: “Serviços de atendimento. Janela lateral aberta.”\n\nFechado: “Janela lateral fechada.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Card Review",
    "estados": "Default, Ativo e Enviado.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o card como uma região de feedback. A leitura segue a ordem do conteúdo informativo antes da ação, ou seja, o leitor anuncia o título, a descrição, os botões de estrela, notas, e o botão.\n\nExemplo:\n\n“Avaliação de experiência. Considerando o uso do Internet Banking Sicredi, avalie como foi sua experiência, sendo 1 estrela muito ruim e 5 estrelas muito boa. Selecione uma nota de 1 a 5. 1 estrela, muito ruim, não selecionado. 2 estrelas, ruim, não selecionado. 3 estrelas, regular, não selecionado. 4 estrelas, boa, não selecionado. 5 estrelas, muito boa, não selecionado. Enviar avaliação, botão, desativado.”\n\nExemplo após selecionar uma nota:\n\n“4 estrelas, boa, selecionado. Campo para comentário exibido. Comentário (opcional), campo de texto multilinha. Enviar avaliação, botão.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Feedback",
    "componente": "Alert",
    "estados": "Ativo e Encerrado.",
    "verbalizacaoEsperada": " o leitor de tela anuncia o alerta automaticamente quando exibido, verbalizando o tipo do alerta antes do conteúdo. Os links são anunciados como conteúdo interativo adicional e o botão de fechar também é anunciado.\n\nExemplo: \"Atualize a sua senha. Sua senha irá expirar em 5 dias. Recomendamos que você a atualize para manter sua conta segura. Saiba mais, link externo. Botão fechar, botão.\"",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Feedback",
    "componente": "Flag",
    "estados": "Estrutural; links internos herdam estados próprios.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o Flag durante a leitura da tela, pois geralmente o Flag já está sendo exibido em tela. Os links são anunciados como conteúdo interativo adicional.\n\nExemplo: “Pendente de autorização. Para concluir a operação, um gestor precisa autorizar. Saiba mais, link externo.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Feedback",
    "componente": "Flag Cooperado",
    "estados": "Estrutural e não interativo; links internos herdam estados.",
    "verbalizacaoEsperada": "o leitor de tela anuncia o Flag Cooperado durante a leitura da tela, pois geralmente já está sendo exibido em tela. Os links são anunciados como conteúdo interativo adicional.\n\nExemplo: \"Campos Gerais. Esta transação fortalece a sua comunidade local. Saiba mais, link externo.\"",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Feedback",
    "componente": "Toast",
    "estados": "Exibido e Oculto.",
    "verbalizacaoEsperada": "A verbalização é iniciada pelo rótulo.\n Exemplo: “Arquivo salvo com sucesso.”\n\nApós a leitura da mensagem, o leitor de tela deve anunciar a presença do botão de fechamento, permitindo interação imediata.\n Exemplo: “Fechar mensagem, botão.”\n\nÍcones, como são elementos de apoio, podem ser ignorados por tecnologias assistivas.",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Feedback",
    "componente": "Tooltip",
    "estados": "Inativo: Tooltip não visível.\n\nAtivo: Tooltip visível por hover ou foco.",
    "verbalizacaoEsperada": "o leitor de tela associa o Tooltip ao elemento de origem. O conteúdo é verbalizado como descrição adicional quando o elemento recebe foco.\n\nExemplo: \"Ícone de informação, ícone, Valor máximo disponível para uso, somando seu saldo e os limites da conta, como cheque especial.\"\n",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Inputs",
    "componente": "Checkbox",
    "estados": "Marcado, Desmarcado, Parcialmente marcado, Desabilitado.",
    "verbalizacaoEsperada": "Marcado: “{rótulo}, caixa de seleção marcada.”\n Exemplo: “Receber notificações, caixa de seleção marcada.”\n\nDesmarcado: “{rótulo}, caixa de seleção desmarcada.”\n Exemplo: “Aceitar termos e condições, caixa de seleção desmarcada.”\n\nParcialmente marcado: “{rótulo}, caixa de seleção parcialmente marcada.”\n Exemplo: “Selecionar todos, caixa de seleção parcialmente marcada.”\n\nDesabilitado: “{rótulo}, caixa de seleção desabilitada.”\n Exemplo: “Notificações por SMS, caixa de seleção desabilitada.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Chip Filter",
    "estados": "Habilitado, Focus.",
    "verbalizacaoEsperada": "A verbalização se concentra na leitura do rótulo.\n\nExemplo: “Últimos 30 dias”.",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Chip Select",
    "estados": "Habilitado, Focus, Hover.",
    "verbalizacaoEsperada": "A verbalização se concentra na leitura do rótulo e do ícone, quando houver.\n\nExemplos:\n\nApenas label: “Últimos 30 dias”\nCom ícone: “Imagem cartão. Cartão de crédito.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Date Picker",
    "estados": "Default: exibe o valor padrão ou o valor selecionado pelo usuário\n\nHover: componente recebeu foco com mouse, alterando visualmente seu estilo\n\nSelected: componente está com sua lista de opções aberta, tendo o mesmo estilo visual do Hover",
    "verbalizacaoEsperada": "ao abrir o Date Picker, o leitor de tela anuncia o conteúdo do calendário. \n\nExemplo: \"Drawer aberta. Data de de emissão. Calendário, junho de 2026; segunda-feira, 14 de junho de 2026; terça-feira, 15 de junho de 2026, hoje; quarta-feira, 16 de junho de 2026, selecionado; quinta-feira, 17 de junho de 2026, indisponível; sexta-feira, 18 de junho de 2026, início do período; sábado, 19 de junho de 2026, dentro do período; terça-feira, 22 de junho de 2026, fim do período. Botão Selecionar data.\"",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Dropdown",
    "estados": "Habilitado, Focus, Open, Error, Disabled.",
    "verbalizacaoEsperada": "o  leitor de tela anuncia o valor atual, além do description, quando tiver.\n\nExemplo: “Tipo de conta, dropdown. Opção atual: Conta corrente. Pressione Enter para expandir.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Code",
    "estados": "enabled, focus, hover, filled.",
    "verbalizacaoEsperada": "a leitura indica que é uma digitação de código, o conteúdo, quando já estiver preenchido e a posição dentro da sequência. Exemplos:\n\nAo focar um input vazio: “Digite o código, campo 1 de 4.”\n\nAo focar um input já preenchido: “2. Código 1 de 4.”\n",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Code Number",
    "estados": "habilitado, focus, hover e preenchido;",
    "verbalizacaoEsperada": "Habilitado: O leitor de tela anuncia o label do componente seguido do tipo de elemento.\nExemplo: “Código de acesso, campo de entrada”.\n\nPreenchido: Cada dígito mascarado é lido como “preenchido”, sem expor o valor.\nExemplo: “Dígito 1, preenchido”.\n\nFocus: Quando um campo recebe foco, o leitor de tela anuncia sua posição na sequência.\nExemplo: “Campo 2 de 6, digite o próximo dígito.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Date",
    "estados": "Padrão: campo vazio e pronto para entrada.\n\nAberto: exibe o calendário de seleção de data.\n\nFoco: realce visual e leitura de rótulo pelo leitor de tela.\n\nPreenchido: exibe a data inserida ou selecionada.\n\nErro: campo marcado com mensagem de erro associada exibida no texto de suporte.\n\nDesativado: campo inativ e com interação bloqueada",
    "verbalizacaoEsperada": "a leitura segue a ordem do conteúdo conforme a renderização, junto da indicação do tipo de componente.\n\nExemplo: “Data de vencimento, campo de data. Nenhuma data selecionada. Pressione Enter para abrir o calendário.\"",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Password",
    "estados": "Habilitado, Focus, Filled, Error, Disabled.",
    "verbalizacaoEsperada": "Campo habilitado e vazio: “{rótulo}, campo de senha.”\nCampo em foco: “{rótulo}, campo de senha, em foco. {texto de apoio}”\nCampo preenchido: “{rótulo}, campo de senha, preenchido.”\nErro: “{rótulo}, campo de senha, erro: {mensagem de erro}.”\nDesabilitado: “{rótulo}, campo de senha, desabilitado.”\nBotão de visibilidade:\n\nSenha oculta: “Mostrar senha, botão, não ativado.”\nSenha visível: “Ocultar senha, botão, ativado.",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Select",
    "estados": "Default, Filled, Hover, Active, Error, Disabled.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o valor atual, quando tiver, além do rótulo e texto de suporte seguidos do tipo de elemento.\n\nHabilitado/Focus: {rótulo}. {texto de suporte}.\n Exemplo: “Categoria. Selecione uma opção. Lista suspensa.”\n\nDesabilitado: {rótulo}. {texto de suporte}. Indisponível.\n Exemplo: “Categoria. Selecione uma opção. Indisponível.”\n\nOpen: o leitor de tela anuncia que a lista foi expandida e passa a vocalizar as opções conforme a navegação.\n Exemplo: “Lista expandida. Opção: Marketing.”\n\nError: caso exista mensagem de erro, ela é anunciada imediatamente após o campo.\n Exemplo: “Categoria, lista suspensa. Erro: seleção obrigatória.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Text",
    "estados": "Habilitado, Focus, Filled, Error, Disabled.",
    "verbalizacaoEsperada": "Habilitado e vazio: “{rótulo}, campo de texto.”\n Exemplo: “Nome completo, campo de texto.”\n\nFocus: “{rótulo}, campo de texto, em foco.”\n Exemplo: “E-mail, campo de texto, em foco.”\n\nFilled: “{rótulo}, campo de texto, preenchido.”\n Exemplo: “E-mail, campo de texto, preenchido.”\n\nError: “{rótulo}, campo de texto, erro: {mensagem de erro}.”\n Exemplo: “CPF, campo de texto, erro: formato inválido.”\n\nDisabled: “{rótulo}, campo de texto, desabilitado.”\n Exemplo: “Telefone, campo de texto, desabilitado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Text Area",
    "estados": "Default, Hover, Focus, Filled, Disabled, Error, Read-only.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o rótulo, o texto de suporte e informa que é um campo de texto.\n\nExemplos:\n\nDefault: {rótulo}, {texto de suporte}, campo de texto.\n Exemplo: “Comentários. Compartilhe a sua opinião. Campo de texto”\n\nFocus: {rótulo}, {texto de suporte}, campo de texto.\n Exemplo: “Comentários. Compartilhe a sua opinião. Campo de texto”\n\nError: {rótulo}, {texto de suporte}, campo de texto.\n Exemplo: “Comentários. Campo obrigatório. Campo de texto”\n\nDisabled: {rótulo}, {texto de suporte}, campo de texto.\n Exemplo: “Comentários. Compartilhe sua opinião. Campo de texto. Desabilitado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "List Select",
    "estados": "Herda do seletor interno: Hover, Focus, Checked, Unchecked, Disabled etc.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o conteúdo textual e o tipo de seletor aplicado, conforme o estado atual.\n\nExemplos:\n\nCheckbox: “Notificações por e-mail, caixa de seleção marcada.”\nRadio: “Conta pessoal, botão de opção selecionado.”\nSwitch: “Receber alertas, alternar ativado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Popover",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "O leitor de tela percorre e lê apenas os elementos internos, conforme sua própria hierarquia semântica. O Popover não é anunciado como elemento independente.",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Inputs",
    "componente": "Popover Menu",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "O leitor de tela percorre e lê apenas os elementos internos, conforme sua própria hierarquia semântica. O Popover não é anunciado como elemento independente.",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Inputs",
    "componente": "Radio Button",
    "estados": "Selecionado, Não selecionado, Desabilitado.",
    "verbalizacaoEsperada": "Selecionado: “{rótulo}, botão de opção selecionado.”\n Exemplo: “Pessoa física, botão de opção selecionado.”\n\nNão selecionado: “{rótulo}, botão de opção não selecionado.”\n Exemplo: “Pessoa jurídica, botão de opção não selecionado.”\n\nDesabilitado: “{rótulo}, botão de opção desabilitado.”\n Exemplo: “Conta corporativa, botão de opção desabilitado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Rate Input",
    "estados": "Default, Selecionado, Desabilitado.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o rótulo acessível e a nota atual, quando houver.\n\nExemplo: “Avaliação do atendimento, 1 de 5 estrelas. Nenhuma avaliação selecionada. Use as setas para escolher uma nota de 1 a 5.”\nExemplo após selecionar uma nota: “4 de 5 estrelas. Selecionado.”\nExemplo desabilitado: “Avaliação do atendimento. Indisponível.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Search",
    "estados": "Habilitado/Focus, Hover, Filled;",
    "verbalizacaoEsperada": "como o leitor de tela deve anunciar o componente.\n\nFocus e vazio: “{placeholder}, campo de pesquisa.” Exemplo: \"Busque aqui, campo de pesquisa.\"\n\nFilled: “{conteúdo preenchido}, campo de pesquisa.” Exemplo: \"Sicredi, campo de pesquisa.\"",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Switch",
    "estados": "Ligado, Desligado, Desabilitado; Default, Selected, Hover, Focus.",
    "verbalizacaoEsperada": "Desligado: “{rótulo}, switch desligado.”\n Exemplo: “Ativar notificações, switch desligado.”\n\nLigado: “{rótulo}, switch ligado.”\n Exemplo: “Ativar notificações, switch ligado.”\n\nAo alternar: “{rótulo}, switch ligado.” ou “{rótulo}, switch desligado.”, conforme o novo estado.\n Exemplo: “Modo escuro, switch ligado.”\n\nDesabilitado: “{rótulo}, switch desabilitado.”\n Exemplo: “Notificações, switch desabilitado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Uploader",
    "estados": "Default: campo está habilitado e aguardando o envio do arquivo.\n\nActive: campo recebeu o foco e está com destaque visual.\n\nLoading: upload em andamento.\n\nCompleted: upload finalizado.\n\nError: falha no envio ou validação.",
    "verbalizacaoEsperada": "o leitor de tela anuncia o rótulo do campo, as instruções e o estado atual do upload, quando houver.\n\n“Enviar arquivo, uploader. Formatos aceitos: PDF, JPG. Tamanho máximo: 10 megabytes. Nenhum arquivo selecionado. Pressione Enter para escolher um arquivo ou arraste e solte.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Navigation",
    "componente": "Avatar Business",
    "estados": "Estático.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar o nome ou a identificação da empresa, sem necessidade de leitura da imagem ou ícone em si. Também deve verbalizar o aviso de notificação representado pelo Badge, se houver.\n\nExemplos:\n\n“Sicredi, empresa.”\n“Sicredi, há novas notificações.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Navigation",
    "componente": "Avatar Name",
    "estados": "Estático.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar o nome da pessoa e, se houver, o aviso de notificação representado pelo Badge.\n\nExemplos:\n\n“João Pereira, perfil.”\n“João Pereira, há novas notificações.”\n\nQuando o nome da pessoa já estiver visível na interface, a imagem ou iniciais podem ser ignoradas pelo leitor de tela.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Navigation",
    "componente": "Breadcrumb",
    "estados": "Links habilitados; página atual.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar os itens na sequência e identificar a página atual ao final.\n\nExemplo: “Início, Produtos. Página atual: Detalhes.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Navigation",
    "componente": "Carousel Nav",
    "estados": "Herda de Page Indicator e Button Icon.",
    "verbalizacaoEsperada": "O leitor de tela anuncia os botões como controles de navegação.\n\nExemplo: “Carrossel. 3 itens. Item 1 de 3. Próximo item, botão.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Navigation",
    "componente": "Header Product",
    "estados": "Estrutural; elementos internos possuem estados próprios.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar primeiro o título principal, seguido da descrição e dos elementos adicionais, conforme sua presença.\n\nExemplos de leitura:\n\n“Configuração de conta. Guia selecionada: Dados pessoais.”\n“Transferência de Pix. Etapa 1 de 4. Selecionar favorecido.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Navigation",
    "componente": "List Navigation",
    "estados": "Default: onde o item está disponível para navegação\n\nHover: estado momentâneo ao acionar a navegação\n\nFocus: componente recebe destaque visual para navegação por teclado.",
    "verbalizacaoEsperada": "o leitor de tela anuncia cada item como link ou botão de navegação, lendo label por label, conforme a ordem de renderização.\n\nExemplo: \"Tire suas dúvidas sem sair do sistema. Atendimento online, link externo.\"\n\n",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Navigation",
    "componente": "Page Indicator",
    "estados": "Informativo e não interativo.",
    "verbalizacaoEsperada": "É recomendado que o Page Indicator não seja anunciado como elemento interativo. A informação de página atual deve ser comunicada pelo componente de navegação, por exemplo, Carousel Nav, ou pelo contexto da tela.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Navigation",
    "componente": "Tab",
    "estados": "Selecionada e Não selecionada.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o conjunto como um grupo de abas e informa o estado de cada uma. Ao selecionar uma aba, o conteúdo do painel ativo deve ser anunciado.\n\nCada aba é verbalizada como “Aba, selecionada” ou “Aba, não selecionada”. Ao mudar de aba, o conteúdo do painel ativo é anunciado.\n\nExemplo: “Abas de conteúdo, 3 abas. Visão geral, aba selecionada. Movimentações, aba não selecionada. Comprovantes, aba não selecionada. Conteúdo da aba Visão geral exibido.”",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Status",
    "componente": "Badge",
    "estados": "Sem estados próprios.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar a presença do Badge junto ao elemento principal.\n\nExemplo: “Notificações, há novas notificações.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Loading",
    "estados": "Único.",
    "verbalizacaoEsperada": "A verbalização informa ao usuário que uma ação está em execução por meio do preenchimento do aria-label.\n\nExemplo: “Carregando conteúdo”.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Progress Line",
    "estados": "Informativo e não interativo.",
    "verbalizacaoEsperada": "O leitor de tela deve comunicar o contexto completo do progresso com base no texto de apoio da tela.\n\nExemplo: “Etapa 2 de 4, Dados do pagamento.”\n\nO Progress Line em si não precisa ser verbalizado, desde que o contexto textual informe de forma clara a etapa atual e o total de etapas.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Skeleton",
    "estados": "Único.",
    "verbalizacaoEsperada": "O Skeleton não deve ser anunciado como conteúdo interativo ou informativo detalhado, apenas para orientar que o conteúdo ainda não está pronto.\n\nExemplo: “O conteúdo está sendo carregado.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Tag Container",
    "estados": "Estático.",
    "verbalizacaoEsperada": "O leitor de tela lê apenas o texto do Label, junto ao contexto em que a Tag está inserida.\n\nExemplo: “Status: Em análise.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Tag Icon",
    "estados": "Estático e não interativo.",
    "verbalizacaoEsperada": "Ícone informativo: “Atrasado, ícone de atenção.”\nÍcone decorativo: “Aprovado.”",
    "tipo": "Não interativo",
    "foco": "Não"
  }
];
