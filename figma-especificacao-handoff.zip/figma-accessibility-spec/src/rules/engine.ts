/**
 * Motor de regras genérico.
 *
 * Este arquivo NÃO conhece nada sobre "acessibilidade" nem sobre
 * "Figma" diretamente. Ele define o contrato que qualquer domínio de
 * regras (acessibilidade hoje, tagueamento/analytics futuramente)
 * precisa implementar, e a função pura que aplica uma regra a um
 * conjunto de dados extraídos.
 *
 * Dados extraídos do Figma (ex.: "primeiro TEXT encontrado") são
 * responsabilidade da camada de análise (src/main/analysis), não
 * deste arquivo.
 */

import { MarkupTypeKey } from "./markupTypes";
import { resolvePlaceholders } from "./placeholders";

export interface ExtractedTextData {
  /** Conteúdo do primeiro node TEXT encontrado dentro do componente, se houver. */
  text?: string;
}

/**
 * Como uma regra de tipo de componente identifica se um determinado
 * componente do Figma corresponde a esse tipo. `nodeName` é o nome
 * do node/instância; `componentName` é o nome do componente principal
 * (quando aplicável).
 */
export interface ComponentIdentifier {
  /** Testa se o nome do componente/instância corresponde a este tipo. */
  matches: (input: { nodeName: string; componentName: string | null }) => boolean;
}

/**
 * Definição de uma regra de tipo de componente para um domínio
 * (ex.: acessibilidade). Ver seção 16 do briefing.
 */
export interface ComponentTypeRule<TExtracted extends object = ExtractedTextData> {
  /** Chave estável usada internamente (ex.: "botao"). */
  key: string;
  /** Nome legível da regra, para documentação/depuração (não é mais exibido no SELECT — ver markupTypes.ts). */
  label: string;
  /**
   * A qual das 12 categorias fixas de "Tipo de marcação" este
   * componente pertence. É esse valor, não `key`/`label`, que aparece
   * selecionado no dropdown da Etapa 2.
   */
  markupType: MarkupTypeKey;
  /** Como identificar automaticamente este tipo a partir do node do Figma. */
  identifier: ComponentIdentifier;
  /** Se este tipo produz verbalização. Se false, o campo fica sempre vazio. */
  hasVerbalization: boolean;
  /**
   * Quais dados devem ser extraídos do Figma para este tipo.
   * "first-text": primeiro TEXT visível encontrado (padrão, a maioria
   * dos componentes). "all-text": todos os textos visíveis, juntados
   * com ", " — para componentes com múltiplos textos que formam a
   * verbalização junto (ex.: Breadcrumb). Os dois preenchem o mesmo
   * campo `extractedData.text`, então uma regra deve usar só um dos
   * dois na prática.
   */
  extraction: Array<"first-text" | "all-text">;
  /**
   * Template de verbalização. Usa placeholders "(Nome)", "[Nome]" ou
   * "{Nome}" — os três estilos usados pela planilha real; ver
   * `placeholders.ts`. Só é usado quando hasVerbalization === true.
   */
  template?: string;
  /**
   * Verbalizações alternativas por estado/variante (ex.: "Habilitado",
   * "Foco", "Loading macOS"), quando a planilha descreve mais de uma.
   * `template` é usado como padrão; `computeVerbalization` tenta
   * primeiro achar um estado deste mapa que bata com o estado real da
   * instância no Figma (ver `selectVerbalizationTemplate` abaixo).
   */
  states?: Record<string, string>;
  /**
   * Se este componente recebe número de Ordem de foco (Regra 3 do
   * documento de regras de acessibilidade). Vem da coluna "Foco" da
   * planilha: true só quando o valor é exatamente "Sim". Componentes
   * do tipo Estrutura têm "Foco" = "Apenas elementos interativos" —
   * ou seja, a ESTRUTURA em si nunca recebe número (focusEligible
   * false), mas os componentes internos dela têm sua própria regra
   * e seu próprio "Foco", então continuam elegíveis normalmente
   * (ver Regra 4 e main/generation/panel.ts).
   */
  focusEligible: boolean;
  /**
   * Se true, a descoberta cria um card para este componente E
   * continua descendo dentro dele procurando outros componentes
   * reconhecidos (ex.: "Header Product", que sempre tem um
   * "Breadcrumb" ou título de verdade dentro). Default (ausente) é
   * false: comportamento padrão de "para aqui, não desce" — ver
   * discovery.ts.
   */
  alwaysDescend: boolean;
}

/**
 * Normaliza uma palavra para comparação: minúsculas, sem espaço nas
 * pontas.
 */
function normalizeWord(word: string): string {
  return word.trim().toLowerCase();
}

/**
 * Extrai os "tokens" de comparação de um rótulo de estado da
 * planilha, considerando a FRASE INTEIRA de cada lado (separado por
 * "/", ex.: "Habilitado/Focus" vira dois tokens: "habilitado" e
 * "focus"). Usado na primeira tentativa de casar com o estado real
 * do Figma — cobre o caso comum de um rótulo ser o nome completo do
 * estado (ex.: "Não selecionada").
 */
function fullPhraseTokens(label: string): string[] {
  return label
    .split("/")
    .map((part) => normalizeWord(part))
    .filter((word) => word.length > 0);
}

/**
 * Reduz cada rótulo à PRIMEIRA PALAVRA de cada lado (ex.: "Disabled
 * macOS" e "Disabled Windows" viram ambos "disabled"). Usada só como
 * segunda tentativa, quando a frase inteira não bateu — serve para
 * rótulos com sufixo de plataforma/variação que o Figma não distingue
 * (o Figma só diz "Disabled", sem macOS/Windows).
 */
function firstWordTokens(label: string): string[] {
  return label
    .split("/")
    .map((part) => part.trim().split(/\s+/)[0])
    .filter((word): word is string => Boolean(word))
    .map(normalizeWord);
}

/**
 * Escolhe, dentre os estados descritos na planilha (`rule.states`),
 * qual texto usar com base no(s) valor(es) reais da instância no
 * Figma (`variantValues` — os VALORES das variant properties da
 * instância, ex.: ["Disabled", "Medium"], sem assumir nome de
 * propriedade específico, já que cada Design System pode nomear
 * diferente).
 *
 * Tenta primeiro casar a FRASE INTEIRA de cada rótulo (cobre estados
 * de duas palavras como "Não selecionada"); só se nada bater tenta de
 * novo usando só a primeira palavra de cada rótulo (cobre rótulos com
 * sufixo de plataforma, como "Disabled macOS"/"Disabled Windows",
 * quando o Figma só diz "Disabled"). Quando mais de um rótulo bate no
 * mesmo passo, usa o PRIMEIRO que aparece na planilha, em vez de não
 * escolher nenhum — decisão explícita do usuário para priorizar ter
 * uma verbalização de verdade em vez de sempre cair no texto
 * genérico.
 *
 * Retorna undefined quando não há `states`, não há variantValues, ou
 * nenhum rótulo bate em nenhum dos dois passos — nesse caso
 * `computeVerbalization` usa `rule.template` (o padrão) normalmente.
 */
export function selectVerbalizationTemplate(
  rule: ComponentTypeRule,
  variantValues: string[]
): string | undefined {
  if (!rule.states || variantValues.length === 0) {
    return undefined;
  }
  const normalizedVariantValues = variantValues.map(normalizeWord);

  for (const tokenize of [fullPhraseTokens, firstWordTokens]) {
    for (const [label, text] of Object.entries(rule.states)) {
      const tokens = tokenize(label);
      if (tokens.some((token) => normalizedVariantValues.includes(token))) {
        return text;
      }
    }
  }
  return undefined;
}

/**
 * Gera a verbalização inicial de um componente a partir da regra do
 * seu tipo e dos dados extraídos. Retorna string vazia quando o tipo
 * não possui verbalização (regra explícita, não texto inventado).
 *
 * `variantValues` (opcional) são os valores de variant properties da
 * instância no Figma — quando informados, tenta primeiro achar um
 * estado específico da planilha que bata (ver
 * `selectVerbalizationTemplate`); sem instância/estado reconhecível,
 * cai no `template` padrão da regra.
 */
export function computeVerbalization(
  rule: ComponentTypeRule | undefined,
  extractedData: Record<string, string>,
  variantValues: string[] = []
): string {
  if (!rule || !rule.hasVerbalization) {
    return "";
  }
  const template = selectVerbalizationTemplate(rule, variantValues) ?? rule.template;
  if (!template) {
    return "";
  }
  return resolvePlaceholders(template, extractedData);
}

/**
 * Encontra a regra correspondente a um componente do Figma, testando
 * cada regra cadastrada do domínio na ordem em que foram definidas.
 * Retorna undefined quando nenhuma regra corresponde (caso "Não
 * especificado", ver seção 21 do briefing).
 */
export function findMatchingRule<TExtracted extends object>(
  rules: ComponentTypeRule<TExtracted>[],
  input: { nodeName: string; componentName: string | null }
): ComponentTypeRule<TExtracted> | undefined {
  return rules.find((rule) => rule.identifier.matches(input));
}

/** Chave reservada para o caso em que nenhuma regra corresponde ao componente. */
export const UNSPECIFIED_TYPE_KEY = "nao-especificado";

export const UNSPECIFIED_TYPE_LABEL = "Não especificado";
