/**
 * ATENÇÃO — ESTE ARQUIVO É UM ESPELHO DIRETO DA PLANILHA.
 *
 * Fonte: "Acessibilidade_Colmeia_Web.xlsx" (aba "Acessibilidade Core
 * Web"), fornecida pelo time de acessibilidade em 10/09/2026 —
 * substitui a planilha anterior ("Extracao_Acessibilidade_Core_Web_
 * 70_Componentes.xlsx") como base de verdade.
 *
 * COMO ATUALIZAR QUANDO A PLANILHA MUDAR
 * ---------------------------------------
 * 1. Abra a planilha nova e confira se as colunas continuam sendo,
 *    nesta ordem: Categoria | Componente | Estados | Verbalização
 *    esperada | Tipo | Foco.
 * 2. Para cada linha (uma por componente), adicione/edite um objeto
 *    neste array seguindo a interface `AccessibilityRuleRecord`
 *    abaixo. Copie o texto das células literalmente — inclusive
 *    quebras de linha (uma string JS com `\n` para cada linha da
 *    célula) e as aspas curvas (“ ”) que a planilha usa.
 * 3. A coluna "Tipo" precisa ser um destes 8 valores exatos: "Botão",
 *    "Entrada", "Link", "Título", "Imagem", "Decorativo", "Estrutura",
 *    "Não interativo" — são os únicos que accessibility-rules.ts sabe
 *    mapear para as categorias do plugin (ver
 *    TIPO_PLANILHA_PARA_MARKUP_TYPE nesse arquivo). Um valor fora
 *    dessa lista faz o componente cair em "Não especificado".
 * 4. A coluna "Foco" precisa ser "Sim", "Não" ou "Apenas elementos
 *    interativos" (ver Regra 3 e 4 do documento de regras — Estrutura
 *    sempre usa "Apenas elementos interativos": a estrutura em si não
 *    recebe número de Ordem de foco, só os componentes internos dela).
 * 5. NÃO edite `accessibility-rules.ts` para registrar um componente
 *    novo — aquele arquivo só TRANSFORMA os registros daqui em regras
 *    do motor (`ComponentTypeRule`). Basta adicionar o registro aqui
 *    que a regra correspondente é gerada automaticamente.
 * 6. Campos vazios na planilha viram `null` aqui — não invente
 *    conteúdo para preenchê-los.
 * 7. Se o nome do componente principal no Figma divergir do nome
 *    aqui (já aconteceu: "Botao defaut" em vez de "Botão Default"),
 *    NÃO crie um registro novo — adicione o nome real em
 *    `aliasesDeNome` no registro existente.
 * 8. Depois de editar, rode `npm run typecheck` e `npm run build`
 *    para confirmar que nada quebrou.
 */

export interface AccessibilityRuleRecord {
  /** Categoria do Design System (ex.: "Action", "Inputs", "Content"). Informativo; não usado pelo motor ainda. */
  categoria: string;
  /** Nome do componente exatamente como está na planilha e (esperado) no componente principal do Figma. */
  componente: string;
  /** Lista de estados possíveis do componente, em texto livre (como veio da planilha). Informativo por ora — ver ComponentTypeRule.states. */
  estados: string | null;
  /**
   * Texto de verbalização esperada, literalmente como veio da célula
   * (pode ter múltiplas linhas/estados, ou ser um texto corrido
   * explicativo com exemplo embutido — os dois casos são usados
   * INTEIROS como verbalização inicial, editável pelo designer;
   * nenhum dos dois fica vazio só porque não é uma lista limpa de
   * "Estado: texto"). Placeholders usam "(Nome)", "[Nome]" ou
   * "{Nome}" dependendo da linha — ver src/rules/placeholders.ts.
   */
  verbalizacaoEsperada: string | null;
  /**
   * Valor literal da coluna "Tipo" da planilha — um dos 8 tipos
   * válidos do documento de regras (Botão, Entrada, Link, Título,
   * Imagem, Decorativo, Estrutura, Não interativo). Mapeado 1:1 para
   * as categorias do plugin em accessibility-rules.ts.
   */
  tipo: string | null;
  /**
   * Coluna "Foco" da planilha: "Sim" | "Não" | "Apenas elementos
   * interativos" | null. Determina a Ordem de foco (Regra 3/4) — só
   * "Sim" torna o componente elegível a receber um número de foco.
   */
  foco: string | null;
  /**
   * NÃO vem da planilha — campo de extensão para quem for dar
   * manutenção depois. Se o nome do componente principal no arquivo
   * Figma real divergir do valor de `componente`, liste aqui os
   * nomes alternativos aceitos. Deixe `undefined` quando não houver
   * divergência conhecida.
   */
  aliasesDeNome?: string[];
  /**
   * NÃO vem da planilha — campo de extensão. Por padrão, um
   * componente reconhecido (com regra aqui) faz a busca parar nele:
   * gera um card, mas não desce para dentro dele. Alguns componentes
   * — como "Header Product" — são reconhecidos E SEMPRE têm outros
   * componentes reais dentro (ex.: Breadcrumb, Título) que também
   * precisam virar card. Marque `true` para esses casos. Default:
   * false (comportamento padrão de "para aqui").
   */
  sempreAprofundar?: boolean;
  /**
   * NÃO vem da planilha — campo de extensão. Por padrão, a extração
   * pega só o primeiro texto visível dentro do componente ("primeiro").
   * Componentes com múltiplos textos que juntos formam a verbalização
   * (ex.: Breadcrumb: "Início, Produtos, Detalhes") usam "todos" —
   * junta todos os textos visíveis, na ordem, separados por vírgula.
   * Default: "primeiro".
   */
  extracaoTexto?: "primeiro" | "todos";
  /**
   * NÃO vem da planilha — campo de extensão. Traduz o NOME de uma
   * propriedade booleana do Figma (quando "true") para o rótulo de
   * estado correspondente aqui na planilha, quando usam palavras
   * diferentes — ex.: a propriedade do Figma se chama "Selected"
   * (inglês), mas o estado no campo `estados`/no texto de verbalização
   * se chama "Marcado" (português). Descoberto testando componente
   * real via log de diagnóstico — adicione um par aqui sempre que
   * confirmar, com dados reais, que uma propriedade do Figma
   * corresponde a um estado com nome diferente.
   */
  stateFlagAliases?: Record<string, string>;
  /**
   * NÃO vem da planilha — campo de extensão. Regras de inferência por
   * AUSÊNCIA de sinal, para estados sem nenhuma propriedade "true"
   * correspondente no Figma (ex.: "Desmarcado" de um Checkbox — não
   * existe "Unselected: true", só a ausência de "Selected"/
   * "Indeterminate"). Cadastre só quando confirmar com dados reais —
   * é específico de cada componente, nunca um algoritmo genérico.
   */
  derivedStates?: Array<{ whenFlagsEqual: Record<string, string>; thenState: string }>;
}

export const accessibilityRuleRecords: AccessibilityRuleRecord[] = [
  {
    "categoria": "Action",
    "componente": "Button Group",
    "estados": "Habilitado, Foco, Desabilitado e Loading. O grupo em si não possui estados próprios.",
    "verbalizacaoEsperada": "Habilitado: “[verbo do botão], botão.”\nFoco: “[verbo do botão], botão.”\nDesabilitado: “[verbo do botão], botão, indisponível.”\nLoading: “[verbo do botão], carregando, botão indisponível.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Action",
    "componente": "Button Icon",
    "estados": "Habilitado, Disabled, Focus, Hover.",
    "verbalizacaoEsperada": "Habilitado: “[verbo do botão], botão.”\nDisabled: “[verbo do botão], botão, indisponível.”\nFocus: “[verbo do botão], botão.”\nCom badge: “[verbo do botão], novas.”",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Button Mini",
    "estados": "Habilitado, Disabled, Focus, Hover.",
    "verbalizacaoEsperada": "Habilitado: “[verbo do botão], botão.”\nDisabled: “[verbo do botão], botão, indisponível.”\nFocus: “[verbo do botão], botão.”",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Button Primary",
    "estados": "Habilitado, Hover, Focus, Loading, Disabled.",
    "verbalizacaoEsperada": "Habilitado/Focus: “[Verbo do botão], botão”.\nLoading macOS: “[Verbo do botão], carregando, botão, escurecido”.\nLoading Windows: “Indisponível, botão, [Verbo do botão]”.\nDisabled macOS: “[Verbo do botão], botão, escurecido”.\nDisabled Windows: “Indisponível, botão, [Verbo do botão]”.",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Button Secondary",
    "estados": "Habilitado, Hover, Focus, Loading, Disabled.",
    "verbalizacaoEsperada": "Habilitado/Focus: “[Verbo do botão], botão”.\nLoading macOS: “[Verbo do botão], carregando, botão, escurecido”.\nLoading Windows: “Indisponível, botão, [Verbo do botão]”.\nDisabled macOS: “[Verbo do botão], botão, escurecido”.\nDisabled Windows: “Indisponível, botão, [Verbo do botão]”.",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Shortcut",
    "estados": "Habilitado, Focus, Hover, Disabled.",
    "verbalizacaoEsperada": "Habilitado/Focus: “{rótulo}, link.”\nDisabled: “{rótulo}, link, indisponível.”",
    "tipo": "Link",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Menu Button",
    "estados": "Recolhido, Expandido, Focus e Hover.",
    "verbalizacaoEsperada": "Recolhido: “[verbo do botão], botão, menu recolhido.”\nExpandido: “[verbo do botão], botão, menu expandido.”\nItem focado: “Editar, item de menu.”",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Action",
    "componente": "Link Icon",
    "estados": "Habilitado, Focus, Hover.",
    "verbalizacaoEsperada": "Habilitado/Focus: “{rótulo}, link.”\nExterno: “{rótulo}, link externo.”",
    "tipo": "Link",
    "foco": "Sim"
  },
  {
    "categoria": "Content",
    "componente": "Icon Shape",
    "estados": "Padrão; estático, sem foco, hover ou desabilitado.",
    "verbalizacaoEsperada": "Não precisa ser lido por leitores de tela.",
    "tipo": "Decorativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Currency",
    "estados": "Padrão, Mascarado; variação positiva ou negativa apenas visual.",
    "verbalizacaoEsperada": "Visível: “{rótulo}”\nMascarado: “Valor oculto por privacidade.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Paragraph",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "Leitura linear do conteúdo: “{rótulo}”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Icon",
    "estados": "Herda estados do componente pai.",
    "verbalizacaoEsperada": "Decorativo: o leitor de tela ignora o ícone.\n Exemplo: nenhum anúncio.\n\nSemântico: “{rótulo}.”\n\nDentro de botão ou link: a leitura é feita a partir do elemento pai.\n Exemplo: “Editar, botão.”",
    "tipo": "Decorativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Topic",
    "estados": "Estático, sem foco, hover ou desabilitado.",
    "verbalizacaoEsperada": "Leitor lê apenas o Label: “{rótulo}”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Brand",
    "estados": "Estático; quando usado como link, possui interação.",
    "verbalizacaoEsperada": "“Logotipo Sicredi”.",
    "tipo": "Imagem",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Description",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "Leitura normal; quando associado, é lido com rótulo principal: “{rótulo}”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Empty State",
    "estados": "Estático; botão interno segue Button Primary.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Content",
    "componente": "Accordion",
    "estados": "Expandido e Recolhido.",
    "verbalizacaoEsperada": "Foco/recolhido: “[título], botão recolhido.”\nExpandido: “[título], botão expandido.” Após a expansão, o conteúdo interno é anunciado em sequência, permitindo uma leitura contínua pelo leitor de tela.",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Content",
    "componente": "Image",
    "estados": "Estático.",
    "verbalizacaoEsperada": "Quando a imagem possui propósito informativo, o leitor de tela anuncia o texto alternativo definido no alt.\n Exemplo: “Gráfico de barras mostrando o aumento de clientes no último trimestre.”\n\nQuando a imagem é meramente decorativa, o alt pode estar vazio para que o leitor de tela a ignore.",
    "tipo": "Imagem",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Heading",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o conteúdo do Label e o nível hierárquico correspondente: “{título}, título.”",
    "tipo": "Título",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "List Content",
    "estados": "Sem estados próprios.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Content",
    "componente": "List Ghost",
    "estados": "Padrão, estático.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Não interativo",
    "foco": "Não",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Content",
    "componente": "Credit Card",
    "estados": "Estático.",
    "verbalizacaoEsperada": "Quando o cartão for exibido junto a informações complementares: “{rótulo}.”\n\nQuando for uma versão genérica, sem bandeira, a leitura deve se apoiar nas informações textuais próximas.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Content",
    "componente": "Pagination",
    "estados": "Estados herdados de Dropdown e Button Icon.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Botão",
    "foco": "Sim",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Content",
    "componente": "Table",
    "estados": "Default, Linhas selecionadas, Sem dados.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar o rótulo acessível seguindo a ordem das colunas e linhas em tela:\n“Tipo do componente, total de linhas e colunas, linha a linha.”\nSe estiver habilitada a seleção de linhas, o seletor é anunciado por linha, antes dos dados.\nSe estiverem habilitados botões, os botões são anunciados por linha, ao final dos dados. \nExemplo:\n“Tabela de lançamentos.\n 4 linhas exibidas de um total de 30.\n 5 colunas: Seleção, Lançamento, Nome, Número do CPF, Valor total, Status.\n Linha 1.\n Não selecionada.\n Nome: Rosana de Lima.\n Valor total: 150 reais.\n Status: Autorizado.\n Linha 2.\n Selecionada.\n Nome: Pedro Luiz Sousa.\n Valor total: 440 reais.\n Status: Pendente.\n Barra de ação.\n 2 itens selecionados.\n Ações disponíveis: Excluir, botão. Autorizar, botão.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Card",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "O leitor de tela percorre e lê apenas os elementos internos, conforme sua própria hierarquia semântica. O Card não é anunciado como elemento independente.",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Banner Image Full",
    "estados": "Habilitado, Focus, Hover, relacionados à ação.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Imagem",
    "foco": "Não",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Containers",
    "componente": "Modal",
    "estados": "Aberto e Fechado; tipos Default, Danger e Positive.",
    "verbalizacaoEsperada": "Quando o modal é aberto, o leitor de tela anuncia o título: “{título}, diálogo.” Em seguida, lê todo o conteúdo em sequência, incluindo mensagens, campos e botões.\n\nAo fechar, o leitor de tela anuncia: “Diálogo fechado.”\n\nComportamento por tipo de modal (referência, não preenchido automaticamente):\n\nDefault: comunica ações neutras ou informativas, sem urgência.\n Exemplo de verbalização: “Detalhes da conta, diálogo.”\n\nDanger: indica ações críticas ou destrutivas.\n Exemplo: “Excluir registro, diálogo de atenção.”\n\nPositive: reforça ações concluídas com sucesso.\n Exemplo: “Transferência realizada, diálogo de confirmação.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Cookies",
    "estados": "Visível e Aceito.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Containers",
    "componente": "Fixed Bar",
    "estados": "Estrutural, sem estados próprios.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Containers",
    "componente": "Drawer",
    "estados": "Aberto e Fechado.",
    "verbalizacaoEsperada": "Aberto: “{rótulo}. Janela lateral aberta.”\nFechado: “Janela lateral fechada.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Containers",
    "componente": "Card Review",
    "estados": "Default, Ativo e Enviado.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o card como uma região de feedback. A leitura segue a ordem do conteúdo informativo antes da ação, ou seja, o leitor anuncia o título, a descrição, os botões de estrela, notas, e o botão.\n\nExemplo:\n\n“Avaliação de experiência. Considerando o uso do Internet Banking Sicredi, avalie como foi sua experiência, sendo 1 estrela muito ruim e 5 estrelas muito boa. Selecione uma nota de 1 a 5. 1 estrela, muito ruim, não selecionado. 2 estrelas, ruim, não selecionado. 3 estrelas, regular, não selecionado. 4 estrelas, boa, não selecionado. 5 estrelas, muito boa, não selecionado. Enviar avaliação, botão, desativado.”\n\nExemplo após selecionar uma nota:\n\n“4 estrelas, boa, selecionado. Campo para comentário exibido. Comentário (opcional), campo de texto multilinha. Enviar avaliação, botão.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Feedback",
    "componente": "Alert",
    "estados": "Ativo e Encerrado.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Feedback",
    "componente": "Flag",
    "estados": "Estrutural; links internos herdam estados próprios.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Feedback",
    "componente": "Flag Cooperado",
    "estados": "Estrutural e não interativo; links internos herdam estados.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Feedback",
    "componente": "Toast",
    "estados": "Exibido e Oculto.",
    "verbalizacaoEsperada": "A verbalização é iniciada pelo rótulo: “{rótulo}.”\n\nApós a leitura da mensagem, o leitor de tela deve anunciar a presença do botão de fechamento, permitindo interação imediata.\n Exemplo: “Fechar mensagem, botão.”\n\nÍcones, como são elementos de apoio, podem ser ignorados por tecnologias assistivas.",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Feedback",
    "componente": "Tooltip",
    "estados": "Inativo: Tooltip não visível.\n\nAtivo: Tooltip visível por hover ou foco.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Não interativo",
    "foco": "Não",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Inputs",
    "componente": "Checkbox",
    "estados": "Marcado, Desmarcado, Parcialmente marcado, Desabilitado.",
    "verbalizacaoEsperada": "Marcado: “{rótulo}, caixa de seleção marcada.”\n Exemplo: “Receber notificações, caixa de seleção marcada.”\n\nDesmarcado: “{rótulo}, caixa de seleção desmarcada.”\n Exemplo: “Aceitar termos e condições, caixa de seleção desmarcada.”\n\nParcialmente marcado: “{rótulo}, caixa de seleção parcialmente marcada.”\n Exemplo: “Selecionar todos, caixa de seleção parcialmente marcada.”\n\nDesabilitado: “{rótulo}, caixa de seleção desabilitada.”\n Exemplo: “Notificações por SMS, caixa de seleção desabilitada.”",
    "tipo": "Entrada",
    "foco": "Sim",
    "stateFlagAliases": {
      "Selected": "Marcado",
      "Indeterminate": "Parcialmente marcado",
      "Disabled": "Desabilitado"
    },
    "derivedStates": [
      {
        "whenFlagsEqual": { "Selected": "False", "Indeterminate": "False", "Disabled": "False" },
        "thenState": "Desmarcado"
      }
    ]
  },
  {
    "categoria": "Inputs",
    "componente": "Chip Filter",
    "estados": "Habilitado, Focus.",
    "verbalizacaoEsperada": "A verbalização se concentra na leitura do rótulo: “{rótulo}”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Chip Select",
    "estados": "Habilitado, Focus, Hover.",
    "verbalizacaoEsperada": "Apenas label: “{rótulo}”\nCom ícone: “Imagem cartão. Cartão de crédito.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Date Picker",
    "estados": "Default: exibe o valor padrão ou o valor selecionado pelo usuário\n\nHover: componente recebeu foco com mouse, alterando visualmente seu estilo\n\nSelected: componente está com sua lista de opções aberta, tendo o mesmo estilo visual do Hover",
    "verbalizacaoEsperada": "ao abrir o Date Picker, o leitor de tela anuncia o conteúdo do calendário. \n\nExemplo: \"Drawer aberta. Data de de emissão. Calendário, junho de 2026; segunda-feira, 14 de junho de 2026; terça-feira, 15 de junho de 2026, hoje; quarta-feira, 16 de junho de 2026, selecionado; quinta-feira, 17 de junho de 2026, indisponível; sexta-feira, 18 de junho de 2026, início do período; sábado, 19 de junho de 2026, dentro do período; terça-feira, 22 de junho de 2026, fim do período. Botão Selecionar data.\"",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Dropdown",
    "estados": "Habilitado, Focus, Open, Error, Disabled.",
    "verbalizacaoEsperada": "{rótulo}, dropdown.",
    "tipo": "Entrada",
    "foco": "Sim",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Code",
    "estados": "enabled, focus, hover, filled.",
    "verbalizacaoEsperada": "a leitura indica que é uma digitação de código, o conteúdo, quando já estiver preenchido e a posição dentro da sequência. Exemplos:\n\nAo focar um input vazio: “Digite o código, campo 1 de 4.”\n\nAo focar um input já preenchido: “2. Código 1 de 4.”\n",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Code Number",
    "estados": "habilitado, focus, hover e preenchido;",
    "verbalizacaoEsperada": "Habilitado: “{rótulo}, campo de entrada.”\nPreenchido: “Dígito preenchido, sem expor o valor.”\nFocus: “Campo em foco, digite o próximo dígito.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Date",
    "estados": "Padrão: campo vazio e pronto para entrada.\n\nAberto: exibe o calendário de seleção de data.\n\nFoco: realce visual e leitura de rótulo pelo leitor de tela.\n\nPreenchido: exibe a data inserida ou selecionada.\n\nErro: campo marcado com mensagem de erro associada exibida no texto de suporte.\n\nDesativado: campo inativ e com interação bloqueada",
    "verbalizacaoEsperada": "{rótulo}, campo de data.",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Password",
    "estados": "Habilitado, Focus, Filled, Error, Disabled.",
    "verbalizacaoEsperada": "Campo habilitado e vazio: “{rótulo}, campo de senha.”\nCampo em foco: “{rótulo}, campo de senha, em foco. {texto de apoio}”\nCampo preenchido: “{rótulo}, campo de senha, preenchido.”\nErro: “{rótulo}, campo de senha, erro: {mensagem de erro}.”\nDesabilitado: “{rótulo}, campo de senha, desabilitado.”\nBotão de visibilidade:\n\nSenha oculta: “Mostrar senha, botão, não ativado.”\nSenha visível: “Ocultar senha, botão, ativado.",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Select",
    "estados": "Default, Filled, Hover, Active, Error, Disabled.",
    "verbalizacaoEsperada": "O leitor de tela anuncia o valor atual, quando tiver, além do rótulo e texto de suporte seguidos do tipo de elemento.\n\nHabilitado/Focus: {rótulo}. {texto de suporte}.\n Exemplo: “Categoria. Selecione uma opção. Lista suspensa.”\n\nDesabilitado: {rótulo}. {texto de suporte}. Indisponível.\n Exemplo: “Categoria. Selecione uma opção. Indisponível.”\n\nOpen: o leitor de tela anuncia que a lista foi expandida e passa a vocalizar as opções conforme a navegação.\n Exemplo: “Lista expandida. Opção: Marketing.”\n\nError: caso exista mensagem de erro, ela é anunciada imediatamente após o campo.\n Exemplo: “Categoria, lista suspensa. Erro: seleção obrigatória.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Text",
    "estados": "Habilitado, Focus, Filled, Error, Disabled.",
    "verbalizacaoEsperada": "Habilitado e vazio: “{rótulo}, campo de texto.”\n Exemplo: “Nome completo, campo de texto.”\n\nFocus: “{rótulo}, campo de texto, em foco.”\n Exemplo: “E-mail, campo de texto, em foco.”\n\nFilled: “{rótulo}, campo de texto, preenchido.”\n Exemplo: “E-mail, campo de texto, preenchido.”\n\nError: “{rótulo}, campo de texto, erro: {mensagem de erro}.”\n Exemplo: “CPF, campo de texto, erro: formato inválido.”\n\nDisabled: “{rótulo}, campo de texto, desabilitado.”\n Exemplo: “Telefone, campo de texto, desabilitado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Input Text Area",
    "estados": "Default, Hover, Focus, Filled, Disabled, Error, Read-only.",
    "verbalizacaoEsperada": "Default: “{rótulo}, {texto de suporte}, campo de texto.”\nFocus: “{rótulo}, {texto de suporte}, campo de texto.”\nError: “{rótulo}, {texto de suporte}, campo de texto.”\nDisabled: “{rótulo}, {texto de suporte}, campo de texto, desabilitado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "List Select",
    "estados": "Herda do seletor interno: Hover, Focus, Checked, Unchecked, Disabled etc.",
    "verbalizacaoEsperada": "Checkbox: “{rótulo}, caixa de seleção marcada.”\nRadio: “{rótulo}, botão de opção selecionado.”\nSwitch: “{rótulo}, alternar ativado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Popover",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "O leitor de tela percorre e lê apenas os elementos internos, conforme sua própria hierarquia semântica. O Popover não é anunciado como elemento independente.",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Inputs",
    "componente": "Popover Menu",
    "estados": "Padrão.",
    "verbalizacaoEsperada": "O leitor de tela percorre e lê apenas os elementos internos, conforme sua própria hierarquia semântica. O Popover não é anunciado como elemento independente.",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Inputs",
    "componente": "Radio Button",
    "estados": "Selecionado, Não selecionado, Desabilitado.",
    "verbalizacaoEsperada": "Selecionado: “{rótulo}, botão de opção selecionado.”\n Exemplo: “Pessoa física, botão de opção selecionado.”\n\nNão selecionado: “{rótulo}, botão de opção não selecionado.”\n Exemplo: “Pessoa jurídica, botão de opção não selecionado.”\n\nDesabilitado: “{rótulo}, botão de opção desabilitado.”\n Exemplo: “Conta corporativa, botão de opção desabilitado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Rate Input",
    "estados": "Default, Selecionado, Desabilitado.",
    "verbalizacaoEsperada": "Sem avaliação: “{rótulo}. Nenhuma avaliação selecionada. Use as setas para escolher uma nota de 1 a 5.”\nCom avaliação: “{rótulo}, selecionado.”\nDesabilitado: “{rótulo}. Indisponível.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Search",
    "estados": "Habilitado/Focus, Hover, Filled;",
    "verbalizacaoEsperada": "{rótulo}, campo de pesquisa.",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Switch",
    "estados": "Ligado, Desligado, Desabilitado; Default, Selected, Hover, Focus.",
    "verbalizacaoEsperada": "Desligado: “{rótulo}, switch desligado.”\n Exemplo: “Ativar notificações, switch desligado.”\n\nLigado: “{rótulo}, switch ligado.”\n Exemplo: “Ativar notificações, switch ligado.”\n\nAo alternar: “{rótulo}, switch ligado.” ou “{rótulo}, switch desligado.”, conforme o novo estado.\n Exemplo: “Modo escuro, switch ligado.”\n\nDesabilitado: “{rótulo}, switch desabilitado.”\n Exemplo: “Notificações, switch desabilitado.”",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Inputs",
    "componente": "Uploader",
    "estados": "Default: campo está habilitado e aguardando o envio do arquivo.\n\nActive: campo recebeu o foco e está com destaque visual.\n\nLoading: upload em andamento.\n\nCompleted: upload finalizado.\n\nError: falha no envio ou validação.",
    "verbalizacaoEsperada": "{rótulo}, uploader. Formatos aceitos: PDF, JPG. Tamanho máximo: 10 megabytes. Nenhum arquivo selecionado. Pressione Enter para escolher um arquivo ou arraste e solte.",
    "tipo": "Entrada",
    "foco": "Sim"
  },
  {
    "categoria": "Navigation",
    "componente": "Avatar Business",
    "estados": "Estático.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar o nome ou a identificação da empresa, sem necessidade de leitura da imagem ou ícone em si: “{rótulo}, empresa.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Navigation",
    "componente": "Avatar Name",
    "estados": "Estático.",
    "verbalizacaoEsperada": "O leitor de tela deve anunciar o nome da pessoa: “{rótulo}, perfil.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Navigation",
    "componente": "Breadcrumb",
    "estados": "Links habilitados; página atual.",
    "verbalizacaoEsperada": "{rótulo}.",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Navigation",
    "componente": "Carousel Nav",
    "estados": "Herda de Page Indicator e Button Icon.",
    "verbalizacaoEsperada": "O leitor de tela anuncia os botões como controles de navegação.\n\nExemplo: “Carrossel. 3 itens. Item 1 de 3. Próximo item, botão.”",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos"
  },
  {
    "categoria": "Navigation",
    "componente": "Header Flow",
    "estados": null,
    "verbalizacaoEsperada": null,
    "tipo": null,
    "foco": null,
    "sempreAprofundar": true
  },
  {
    "categoria": "Navigation",
    "componente": "Header Product",
    "estados": "Estrutural; elementos internos possuem estados próprios.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos",
    "sempreAprofundar": true
  },
  {
    "categoria": "Navigation",
    "componente": "List Navigation",
    "estados": "Default: onde o item está disponível para navegação\n\nHover: estado momentâneo ao acionar a navegação\n\nFocus: componente recebe destaque visual para navegação por teclado.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Estrutura",
    "foco": "Apenas elementos interativos",
    "extracaoTexto": "todos"
  },
  {
    "categoria": "Navigation",
    "componente": "Page Indicator",
    "estados": "Informativo e não interativo.",
    "verbalizacaoEsperada": "É recomendado que o Page Indicator não seja anunciado como elemento interativo. A informação de página atual deve ser comunicada pelo componente de navegação, por exemplo, Carousel Nav, ou pelo contexto da tela.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Navigation",
    "componente": "Tab",
    "estados": "Selecionada e Não selecionada.",
    "verbalizacaoEsperada": "Selecionada: \u201c{rótulo}, aba selecionada.\u201d\nNão selecionada: \u201c{rótulo}, aba não selecionada.\u201d",
    "tipo": "Botão",
    "foco": "Sim"
  },
  {
    "categoria": "Status",
    "componente": "Badge",
    "estados": "Sem estados próprios.",
    "verbalizacaoEsperada": "{rótulo}, há novas notificações.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Loading",
    "estados": "Único.",
    "verbalizacaoEsperada": "{rótulo}",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Progress Line",
    "estados": "Informativo e não interativo.",
    "verbalizacaoEsperada": "O leitor de tela deve comunicar o contexto completo do progresso com base no texto de apoio da tela.\n\nExemplo: “Etapa 2 de 4, Dados do pagamento.”\n\nO Progress Line em si não precisa ser verbalizado, desde que o contexto textual informe de forma clara a etapa atual e o total de etapas.",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Skeleton",
    "estados": "Único.",
    "verbalizacaoEsperada": "O Skeleton não deve ser anunciado como conteúdo interativo ou informativo detalhado, apenas para orientar que o conteúdo ainda não está pronto.\n\nExemplo: “O conteúdo está sendo carregado.”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Tag Container",
    "estados": "Estático.",
    "verbalizacaoEsperada": "O leitor de tela lê apenas o texto do Label, junto ao contexto em que a Tag está inserida: “{rótulo}”",
    "tipo": "Não interativo",
    "foco": "Não"
  },
  {
    "categoria": "Status",
    "componente": "Tag Icon",
    "estados": "Estático e não interativo.",
    "verbalizacaoEsperada": "Informativo: “{rótulo}, ícone de atenção.”\nDecorativo: “{rótulo}.”",
    "tipo": "Não interativo",
    "foco": "Não"
  }
];
